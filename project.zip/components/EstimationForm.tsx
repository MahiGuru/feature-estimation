'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, X, Sparkles, Users, Clock, Target, Zap, FileText, Settings, Star, TrendingUp, Award, Lightbulb } from 'lucide-react';
import { EstimationData, TeamMember } from '@/lib/types';
import { PREDEFINED_FEATURES, generateAIEstimation, saveEstimationData } from '@/lib/estimationData';
import { useToast } from '@/hooks/use-toast';

export default function EstimationForm() {
  const { toast } = useToast();
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [customFeature, setCustomFeature] = useState('');
  const [sprintSize, setSprintSize] = useState<number>(2);
  const [teamMembers, setTeamMembers] = useState<TeamMember>({
    developers: 0,
    qa: 0,
    po: 0,
    ba: 0,
    managers: 0,
    deliveryManagers: 0,
    architects: 0
  });
  const [sprintVelocity, setSprintVelocity] = useState<number>(20);
  const [dependencies, setDependencies] = useState('');
  const [customNotes, setCustomNotes] = useState('');
  const [aiEstimation, setAiEstimation] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const addFeature = (feature: string) => {
    if (feature && !selectedFeatures.includes(feature)) {
      setSelectedFeatures([...selectedFeatures, feature]);
      setCustomFeature('');
    }
  };

  const removeFeature = (feature: string) => {
    setSelectedFeatures(selectedFeatures.filter(f => f !== feature));
  };

  const updateTeamMember = (role: keyof TeamMember, value: number) => {
    setTeamMembers(prev => ({
      ...prev,
      [role]: value
    }));
  };

  const handleGenerateAI = async () => {
    if (selectedFeatures.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one feature",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    try {
      const estimation = await generateAIEstimation({
        features: selectedFeatures,
        sprintSize,
        teamMembers,
        sprintVelocity,
        dependencies,
        customNotes
      });
      setAiEstimation(estimation);
      toast({
        title: "AI Estimation Generated",
        description: "Your project estimation has been generated successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate AI estimation",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveEstimation = () => {
    if (!aiEstimation) {
      toast({
        title: "Error",
        description: "Please generate AI estimation first",
        variant: "destructive"
      });
      return;
    }

    const estimationData: EstimationData = {
      id: Date.now().toString(),
      features: selectedFeatures,
      sprintSize,
      teamMembers,
      sprintVelocity,
      dependencies,
      customNotes,
      aiEstimation,
      createdAt: new Date()
    };

    saveEstimationData(estimationData);
    toast({
      title: "Success",
      description: "Estimation saved successfully"
    });

    // Reset form
    setSelectedFeatures([]);
    setSprintSize(2);
    setTeamMembers({
      developers: 0,
      qa: 0,
      po: 0,
      ba: 0,
      managers: 0,
      deliveryManagers: 0,
      architects: 0
    });
    setSprintVelocity(20);
    setDependencies('');
    setCustomNotes('');
    setAiEstimation(null);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-12">
     
      {/* Features & Dependencies Card */}
      <Card className="professional-card">
        <CardHeader>
          <CardTitle className="section-header">
            <div className="icon-wrapper bg-gradient-to-br from-blue-100 to-blue-200">
              <Target className="w-6 h-6 text-blue-600" />
            </div>
            <span>Features & Dependencies</span>
            <div className="ml-auto">
              <Badge className="bg-blue-100 text-blue-700 border border-blue-200">
                {selectedFeatures.length} selected
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="form-section">
          <div className="space-y-6">
            <div className="form-label">
              <Lightbulb className="w-5 h-5 text-blue-600" />
              <span>Project Features</span>
            </div>
            <div className="flex space-x-4">
              <Select onValueChange={addFeature}>
                <SelectTrigger className="form-input flex-1">
                  <SelectValue placeholder="Select predefined features" />
                </SelectTrigger>
                <SelectContent>
                  {PREDEFINED_FEATURES.map(feature => (
                    <SelectItem key={feature} value={feature}>
                      {feature}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                type="button"
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-6 shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => addFeature(customFeature)}
                disabled={!customFeature}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <Input
              className="form-input"
              placeholder="Enter custom feature"
              value={customFeature}
              onChange={(e) => setCustomFeature(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addFeature(customFeature)}
            />
            <div className="flex flex-wrap gap-4">
              {selectedFeatures.map(feature => (
                <Badge key={feature} className="feature-badge">
                  <span>{feature}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-5 w-5 p-0 text-blue-600 hover:text-blue-800 hover:bg-blue-200 rounded-full"
                    onClick={() => removeFeature(feature)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </Badge>
              ))}
            </div>
          </div>

          <div className="section-divider"></div>

          <div className="space-y-4">
            <div className="form-label">
              <Settings className="w-5 h-5 text-blue-600" />
              <span>Dependencies & Blockers</span>
            </div>
            <Textarea
              id="dependencies"
              className="form-input min-h-[120px]"
              placeholder="List any external dependencies, third-party integrations, or potential blockers that might impact the project timeline..."
              value={dependencies}
              onChange={(e) => setDependencies(e.target.value)}
              rows={5}
            />
          </div>
        </CardContent>
      </Card>

      {/* Sprint Configuration Card */}
      <Card className="professional-card">
        <CardHeader>
          <CardTitle className="section-header">
            <div className="icon-wrapper bg-gradient-to-br from-green-100 to-green-200">
              <Clock className="w-6 h-6 text-green-600" />
            </div>
            <span>Sprint Configuration</span>
            <div className="ml-auto">
              <Badge className="bg-green-100 text-green-700 border border-green-200">
                {sprintVelocity} SP/sprint
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="form-section">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="team-input-group">
              <div className="form-label">
                <Clock className="w-5 h-5 text-blue-600" />
                <span>Sprint Duration</span>
              </div>
              <Input
                id="sprintSize"
                type="number"
                className="form-input text-center text-lg font-semibold"
                value={sprintSize}
                onChange={(e) => setSprintSize(Number(e.target.value))}
                min="1"
                max="8"
              />
              <p className="text-sm text-blue-600 text-center">weeks per sprint</p>
            </div>

            <div className="team-input-group">
              <div className="form-label">
                <Zap className="w-5 h-5 text-blue-600" />
                <span>Team Velocity</span>
              </div>
              <Input
                id="sprintVelocity"
                type="number"
                className="form-input text-center text-lg font-semibold"
                value={sprintVelocity}
                onChange={(e) => setSprintVelocity(Number(e.target.value))}
                min="1"
                max="100"
              />
              <p className="text-sm text-blue-600 text-center">story points per sprint</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Team Members Card */}
      <Card className="professional-card">
        <CardHeader>
          <CardTitle className="section-header">
            <div className="icon-wrapper bg-gradient-to-br from-purple-100 to-purple-200">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <span>Team Composition</span>
            <div className="ml-auto">
              <Badge className="bg-purple-100 text-purple-700 border border-purple-200">
                {Object.values(teamMembers).reduce((a, b) => a + b, 0)} members
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="form-section">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Object.entries(teamMembers).map(([role, count]) => (
              <div key={role} className="team-input-group">
                <Label htmlFor={role} className="text-sm font-semibold text-blue-800 capitalize mb-3 block">
                  {role.replace(/([A-Z])/g, ' $1').trim()}
                </Label>
                <Input
                  id={role}
                  type="number"
                  className="form-input text-center text-lg font-semibold"
                  value={count}
                  onChange={(e) => updateTeamMember(role as keyof TeamMember, Number(e.target.value))}
                  min="0"
                  max="20"
                />
                <div className="text-xs text-blue-600 text-center mt-2">
                  {count === 1 ? 'person' : 'people'}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Custom Notes Card */}
      <Card className="professional-card">
        <CardHeader>
          <CardTitle className="section-header">
            <div className="icon-wrapper bg-gradient-to-br from-orange-100 to-orange-200">
              <FileText className="w-6 h-6 text-orange-600" />
            </div>
            <span>Additional Notes</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="form-section">
          <div className="space-y-4">
            <div className="form-label">
              <FileText className="w-5 h-5 text-blue-600" />
              <span>Project Notes & Requirements</span>
            </div>
            <Textarea
              id="customNotes"
              className="form-input min-h-[150px]"
              placeholder="Add any additional notes, special requirements, assumptions, or important considerations for this project estimation..."
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              rows={6}
            />
          </div>
        </CardContent>
      </Card>

      {/* Generate AI Button */}
      <div className="text-center py-8">
        <Button
          onClick={handleGenerateAI}
          disabled={isGenerating || selectedFeatures.length === 0}
          className="gradient-button px-16 py-6 text-xl pulse-shadow rounded-2xl"
          size="lg"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-6 h-6 mr-4 animate-spin" />
              Generating AI Estimation...
            </>
          ) : (
            <>
              <Sparkles className="w-6 h-6 mr-4" />
              Generate AI Estimation
            </>
          )}
        </Button>
        <p className="text-blue-600/70 mt-4 text-sm">
          Our AI will analyze your requirements and provide detailed estimations
        </p>
      </div>

      {/* AI Estimation Results */}
      {aiEstimation && (
        <Card className="ai-results-card">
          <CardHeader>
            <CardTitle className="section-header">
              <div className="icon-wrapper bg-gradient-to-br from-green-100 to-green-200">
                <Sparkles className="w-6 h-6 text-green-600" />
              </div>
              <span>AI Estimation Results</span>
              <div className="ml-auto">
                <Badge className="bg-green-100 text-green-700 border border-green-200">
                  Generated
                </Badge>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="form-section">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
              <div className="metric-card">
                <div className="text-4xl font-bold text-blue-600 mb-3">
                  {aiEstimation.totalStoryPoints}
                </div>
                <div className="text-sm font-medium text-blue-500">Total Story Points</div>
                <div className="w-full bg-blue-100 rounded-full h-2 mt-3">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
              <div className="metric-card">
                <div className="text-4xl font-bold text-green-600 mb-3">
                  {aiEstimation.estimatedSprints}
                </div>
                <div className="text-sm font-medium text-green-500">Estimated Sprints</div>
                <div className="w-full bg-green-100 rounded-full h-2 mt-3">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              <div className="metric-card">
                <div className={`text-4xl font-bold mb-3 ${
                  aiEstimation.riskLevel === 'High' ? 'text-red-600' :
                  aiEstimation.riskLevel === 'Medium' ? 'text-orange-600' :
                  'text-green-600'
                }`}>
                  {aiEstimation.riskLevel}
                </div>
                <div className="text-sm font-medium text-gray-500">Risk Level</div>
                <div className="w-full bg-gray-100 rounded-full h-2 mt-3">
                  <div 
                    className={`h-2 rounded-full ${
                      aiEstimation.riskLevel === 'High' ? 'bg-red-600' :
                      aiEstimation.riskLevel === 'Medium' ? 'bg-orange-600' :
                      'bg-green-600'
                    }`}
                    style={{ 
                      width: aiEstimation.riskLevel === 'High' ? '90%' :
                             aiEstimation.riskLevel === 'Medium' ? '60%' : '30%'
                    }}
                  ></div>
                </div>
              </div>
            </div>
            
            <div className="section-divider"></div>
            
            <div className="space-y-6">
              <div className="form-label">
                <Lightbulb className="w-5 h-5 text-blue-600" />
                <span>AI Recommendations</span>
              </div>
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200/50">
                <ul className="space-y-4">
                {aiEstimation.recommendations.map((rec: string, index: number) => (
                  <li key={index} className="flex items-start space-x-4 text-blue-800">
                    <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-white text-xs font-bold">{index + 1}</span>
                    </div>
                    <span className="leading-relaxed">{rec}</span>
                  </li>
                ))}
                </ul>
              </div>
            </div>

            <div className="text-center pt-6">
              <Button 
              onClick={handleSaveEstimation} 
              className="gradient-button px-12 py-4 text-lg rounded-2xl shadow-xl hover:shadow-2xl"
              >
              Save Estimation
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}